import pygame
import sys

from lanes import Lanes
from character import Character
from background import Background
from obstacles import Obstacle

pygame.init()

pygame.display.set_caption("Syntax Escape")
class Game:
    def __init__(self):
        self.WIDTH, self.HEIGHT = 800, 800
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        self.clock = pygame.time.Clock()
        self.state = "start"
        self.background = Background(800, 800)

        self.obstacles = []
        self.spawn_timer = 0
        self.spawn_delay = 3


        self.meters = 0
        self.meter_speed = 5
        self.font = pygame.font.SysFont(None, 40)

        self.lanes = Lanes(self.WIDTH, self.HEIGHT)


        self.player = Character(self.lanes, self.HEIGHT)

        self.running = True


    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.state == "start":
                    self.state = "playing"

                elif self.state == "game_over":
                    self.restart()

            if self.state == "playing":
                self.player.handle_input(event)

    def restart(self):
        self.obstacles.clear()
        self.meters = 0
        self.spawn_timer = 0
        self.player = Character(self.lanes, self.HEIGHT)
        self.state = "playing"



    def update(self, dt):
        self.player.update(dt)

        self.background.update()

        self.meters += self.meter_speed * dt
        self.spawn_timer += dt

        if self.spawn_timer >= self.spawn_delay:
            self.obstacles.append(Obstacle(self.lanes, self.HEIGHT))
            self.spawn_timer = 0

        for obs in self.obstacles:
            obs.update(dt)

        self.obstacles = [o for o in self.obstacles if not o.is_off_screen()]


        for obs in self.obstacles:


            if obs.y < 0:
                continue

            if self.player.hitbox.colliderect(obs.hitbox):


                if obs.type == "low":
                    if not self.player.is_jumping:
                        print("HIT LOW OBSTACLE")
                        self.state = "game_over"


                elif obs.type == "high":
                    if self.player.state != "crouch":
                        print("HIT HIGH OBSTACLE")
                        self.state = "game_over"

    def draw_text(self, text, x, y):
        surface = self.font.render(text, True, (255, 255, 255))
        self.screen.blit(surface, (x, y))


    def draw(self):
        self.screen.fill((30, 30, 30))

        if self.state == "start":
            self.draw_text("CLICK TO START", 250, 350)
            pygame.display.flip()
            return

        self.background.draw(self.screen)

        for obs in self.obstacles:
            obs.draw(self.screen)

        self.player.draw(self.screen)

        meter_text = self.font.render(f"{int(self.meters)} m", True, (255, 255, 255))
        self.screen.blit(meter_text, (20, 20))

        if self.state == "game_over":
            self.draw_text("GAME OVER - CLICK TO RETRY", 120, 350)

        pygame.display.flip()


    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000

            self.handle_events()
            self.update(dt)
            self.draw()


        pygame.quit()
        sys.exit()


Game().run()
